import React, { useState, useEffect, useRef, useContext } from 'react';
import axios from 'axios';
import Cookies from 'js-cookie';
import { AuthContext } from './Auth';
import './ChatApp.css';
import { TopClientesChart, MarketShareChart, ClienteAnalysisChart } from './Charts';
import './Charts.css';
import { TrainerMode } from './TrainerMode';
import { DynamicChart } from './DynamicChart';
import { UploadExcel } from './UploadExcel';
import { ImportExport } from './ImportExport';
import { ExportButtons } from './ExportButtons';
import { AuditLogs } from './AuditLogs';
import { SavedResponses } from './SavedResponses';

const API_URL = 'http://127.0.0.1:5000/api';

export default function ChatApp() {
  const { user, logout } = useContext(AuthContext);
  const [messages, setMessages] = useState([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);
  const messagesEndRef = useRef(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sessionId, setSessionId] = useState(null);

  const loadHistory = async () => {
    try {
      const token = Cookies.get('jarvis_token');
      const res = await axios.get(`${API_URL}/chat/history`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const sessions = res.data.sessions || [];
      
      setHistory(sessions.map(s => ({
        session_id: s.session_id,
        messages: s.messages,
        created_at: s.created_at
      })));
    } catch (e) {
      console.error('Error loading history:', e);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (!sessionId) {
      setSessionId(`session_${user.user_id}_${Date.now()}`);
    }
  }, [user, sessionId]);

  useEffect(() => {
    loadHistory();
  }, []);

  const sendQuery = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    const msg = query;
    setQuery('');
    setMessages(p => [...p, { type: 'user', content: msg }]);
    setLoading(true);

    try {
      const token = Cookies.get('jarvis_token');
      
      const res = await axios.post(
        `${API_URL}/query`,
        { query: msg, session_id: sessionId },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (res.data.success) {
        setMessages(p => [...p, { 
          type: 'bot', 
          content: res.data.response,
          query_type: res.data.query_type,
          chart_config: res.data.chart_config,
          rows: res.data.rows
        }]);
        loadHistory();
      } else {
        setMessages(p => [...p, { type: 'error', content: `Error: ${res.data.error}` }]);
      }
    } catch (e) {
      setMessages(p => [...p, { type: 'error', content: `Error: ${e.message}` }]);
    } finally {
      setLoading(false);
    }
  };

  const selectSession = (session) => {
    setMessages(session.messages.flatMap((m) => [
      { type: 'user', content: m.query },
      { 
        type: 'bot', 
        content: m.response,
        query_type: m.query_type,
        chart_config: m.chart_config,
        rows: m.rows
      }
    ]));
  };

  const deleteConv = async (id) => {
    try {
      const token = Cookies.get('jarvis_token');
      const res = await axios.delete(`${API_URL}/chat/history/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      if (res.data.success) {
        loadHistory();
        console.log('✅ Chat eliminado:', id);
      }
    } catch (e) {
      console.error('❌ Error deleting:', e.response?.data || e.message);
    }
  };

  const handleNewChat = () => {
    setMessages([]);
    setSessionId(`session_${user.user_id}_${Date.now()}`);
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="app-layout">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <h1>JARVIS</h1>
          <button className="logout-btn" onClick={handleLogout} title="Logout">
            ⎋
          </button>
        </div>

        <button className="new-chat-btn" onClick={handleNewChat}>
          + New Chat
        </button>
        <ImportExport />
        <SavedResponses />
        <AuditLogs />
        
        <div className="history-container">
          <div className="history-label">Conversations</div>
          
          <input
            type="text"
            placeholder="🔍 Buscar..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
          
          <div className="history-list">
            {history.length ? (
              history
                .filter(session => 
                  session.messages.some(m =>
                    m.query.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    m.response.toLowerCase().includes(searchQuery.toLowerCase())
                  )
                )
                .map(session => (
                  <div key={session.session_id} className="history-session">
                    <button
                      className="history-item"
                      onClick={() => selectSession(session)}
                      title={session.messages[0]?.query}
                    >
                      {session.messages[0]?.query.substring(0, 35)}...
                    </button>
                    <button 
                      className="delete-btn"
                      onClick={() => deleteConv(session.messages[0].id)}
                      title="Eliminar chat"
                    >
                      🗑️
                    </button>
                  </div>
                ))
            ) : (
              <div className="history-empty">Sin conversaciones</div>
            )}
          </div>
        </div>

        <div className="sidebar-footer">
          <div className="user-info">
            <div className="user-avatar">{user?.username?.[0]?.toUpperCase()}</div>
            <div>
              <div className="user-name">{user?.username}</div>
              <div className="user-role">{user?.role}</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Chat */}
      <main className="chat-area">
        <div className="chat-header">
          <div>
            <h2>JARVIS - Analytics</h2>
            <p>Facturación, rankings, comparaciones y análisis de clientes.</p>
          </div>
        </div>

        <div className="chat-container">
          {!messages.length ? (
            <div className="welcome-state">
              <h3>Welcome to JARVIS</h3>
              <p>Ask about billing, clients, rankings, comparisons and investment analysis</p>
              <div className="example-queries">
                <button onClick={() => { setQuery('Muestra un gráfico de barras de los top 5 clientes'); }}>Top 5 clientes</button>
                <button onClick={() => { setQuery('Gráfico: clientes que más facturaron'); }}>Clientes facturación</button>
                <button onClick={() => { setQuery('Cuánto facturó CERVEPAR?'); }}>Facturación cliente</button>
              </div>
            </div>
          ) : (
            <div className="messages">
              {messages.map((m, i) => (
                <div key={i}>
                  <div className={`message ${m.type}`}>
                    <div className="message-bubble">
                      {m.content}
                      {m.type === 'bot' && <TrainerMode message={m} index={i} userQuery={messages[i-1]?.content || ''} />}
                    </div>
                    {m.type === 'bot' && (
                      <ExportButtons message={m} chartConfig={m.chart_config} chartData={m.rows} />
                    )}
                  </div>
                  {m.chart_config && m.rows && <DynamicChart data={m.rows} config={m.chart_config} />}
                  {m.query_type === 'ranking' && m.rows && !m.chart_config && <TopClientesChart data={m.rows} />}
                  {m.query_type === 'ranking' && m.rows && !m.chart_config && <MarketShareChart data={m.rows} />}
                  {m.query_type === 'facturacion' && m.rows && !m.chart_config && <ClienteAnalysisChart data={m.rows} />}
                </div>
              ))}
              {loading && (
                <div className="message bot">
                  <div className="message-bubble loading">Processing...</div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        <form className="input-form" onSubmit={sendQuery}>
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendQuery(e);
              }
            }}
            placeholder="Ask me anything..."
            disabled={loading}
          />
          <button type="submit" disabled={loading}>
            Send
          </button>
        </form>
      </main>
    </div>
  );
}